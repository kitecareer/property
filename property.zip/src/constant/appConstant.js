// export const formNames={
//     Property_Details:'Property Details',
//     Locality_Details:'Locality Details',
//     Rental_Details:'Rental Details',
//     Amenities:'Amenities',
//     Gallery:'Gallery'
// }